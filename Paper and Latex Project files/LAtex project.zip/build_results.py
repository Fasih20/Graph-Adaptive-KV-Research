"""Regenerate tables and vector figures from the bundled result summaries."""
import csv
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
sim = json.loads((ROOT/'data/archived_simulation_summary.json').read_text())
with (ROOT/'data/qwen_real_means.csv').open() as f:
    real = list(csv.DictReader(f))
with (ROOT/'data/api_summary.csv').open() as f:
    api = list(csv.DictReader(f))
labels = {'no_prefetch':'No prefetch','cosine':'Cosine','graph_fixed':'Fixed graph',
          'adaptive_offline_global':'Offline global','adaptive_online_warm':'Online warm'}
policies = list(labels)
models = ['Qwen2.5-1.5B','Qwen2.5-3B','Qwen2.5-7B','Llama-3.2-1B','Llama-3.2-3B','Gemma-3-1B']
ks = [6,10,16]
def row(p,k):
    return next(r for r in real if r['policy']==p and int(r['k'])==k)
def val(r,key,pct=False):
    return f'{float(r[key])*(100 if pct else 1):.2f}'
def table(name,caption,label,columns,header,rows):
    text = '\\begin{table}[t]\n\\centering\\small\n\\caption{'+caption+'}\\label{'+label+'}\n'
    text += '\\begin{tabular}{'+columns+'}\n\\toprule\n'+header+' \\\\\n\\midrule\n'
    text += '\n'.join(rows)+'\n\\bottomrule\n\\end{tabular}\n\\end{table}\n'
    (ROOT/'tables'/name).write_text(text)

rows=[]
for m in models:
    s=sim[m]['condition_stats']['10']
    numbers=[f"{s[p]['mean_ms']:.3f}" if p in s else '--' for p in ['cold','cosine','graph','adaptive']]
    rows.append(m+' & '+' & '.join(numbers)+f" & {s['cosine']['n']:,}"+r' \\')
table('simulation_k10.tex','Archived simulated-cache means at $K=10$ (ms). $N$ is the number of observations per reported policy mean. Adaptive is the historical query-type policy.','tab:sim','lrrrrr','Model & No prefetch & Cosine & Fixed graph & Adaptive & $N$',rows)
rows=[]
for p in policies:
    values=[]
    for k in ks:
        r=row(p,k); values.extend([val(r,'prediction_recall',True),val(r,'mean_ready_cache_ttft_ms')])
    rows.append(labels[p]+' & '+' & '.join(values)+r' \\')
table('real_primary.tex','Real Qwen2.5-1.5B results. R is prediction recall (\\%); T is ready-cache TTFT (ms). Each policy--budget mean contains 1,200 repeated trace observations.','tab:real','lrrrrrr','& \\multicolumn{2}{c}{$K=6$} & \\multicolumn{2}{c}{$K=10$} & \\multicolumn{2}{c}{$K=16$} \\\\ \nPolicy & R & T & R & T & R & T',rows)
rows=[]
for p in policies:
    rows.append(labels[p]+' & '+' & '.join(val(row(p,k),'mean_end_to_end_ttft_ms') for k in ks)+r' \\')
table('real_e2e.tex','End-to-end TTFT (ms), including policy time and all synchronous candidate-population time.','tab:e2e','lrrr','Policy & $K=6$ & $K=10$ & $K=16$',rows)
rows=[]
for dataset in ['HotpotQA','2WikiMultiHopQA']:
    rows.append(r'\multicolumn{5}{l}{\textit{'+dataset+r'}} \\')
    for p in policies[1:]:
        r=next(a for a in api if a['dataset']==dataset and a['policy']==p)
        rows.append(labels[p]+' & '+' & '.join(val(r,x,True) for x in ['em','f1','support_recall','target_hit'])+r' \\')
table('api_results.tex','Gemini 3.5 Flash-Lite answer quality at $K=10$, $M=5$. All metrics are percentages; each policy answers the same 60 questions within a dataset. Support is fully delivered supporting-sentence recall.','tab:api','lrrrr','Policy & EM & F1 & Support & Target hit',rows)

chunks=[]
for index,m in enumerate(models):
    if index and index%3==0: chunks.append(r'\clearpage')
    chunks.append(r'\subsection*{'+m+'}')
    chunks.append('Dataset pool: '+', '.join(sim[m]['datasets_pooled'])+'.')
    chunks.append(r'\begin{center}\small\begin{tabular}{rrrrr}\toprule $K$ & No prefetch & C & G & A \\ \midrule')
    for k,s in sorted(sim[m]['condition_stats'].items(),key=lambda x:int(x[0])):
        chunks.append(k+' & '+' & '.join(f"{s[p]['mean_ms']:.3f}" if p in s else '--' for p in ['cold','cosine','graph','adaptive'])+r' \\')
    chunks.append(r'\bottomrule\end{tabular}\end{center}')
(ROOT/'tables/simulation_all.tex').write_text('\n'.join(chunks))
chunks=[]
for k in ks:
    chunks.append(r'\subsection*{Budget $K='+str(k)+'$}')
    chunks.append(r'\begin{center}\small\begin{tabular}{lrrrr}\toprule Policy & Service ms & Population ms & E2E request ms & Policy ms \\ \midrule')
    for p in policies:
        r=row(p,k)
        chunks.append(labels[p]+' & '+' & '.join(val(r,x) for x in ['mean_service_request_ms','mean_speculative_population_ms','mean_end_to_end_request_ms','mean_policy_ms'])+r' \\')
    chunks.append(r'\bottomrule\end{tabular}\end{center}')
    chunks.append(r'\begin{center}\small\begin{tabular}{lrrrrr}\toprule Policy & KV MiB & Shadow res. \% & Reused tokens & Evictions & Update \% \\ \midrule')
    for p in policies:
        r=row(p,k)
        nums=[val(r,'mean_completed_prefetch_mib'),val(r,'shadow_residency_rate',True),val(r,'mean_lmcache_retrieved_tokens'),val(r,'mean_prefetch_evictions'),val(r,'online_update_rate',True)]
        chunks.append(labels[p]+' & '+' & '.join(nums)+r' \\')
    chunks.append(r'\bottomrule\end{tabular}\end{center}')
(ROOT/'tables/real_diagnostics.tex').write_text('\n'.join(chunks))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42})
fig,axes=plt.subplots(1,2,figsize=(7.2,2.6))
colors=['#56B4E9','#0072B2','#009E73','#CC79A7']
for p,color in zip(policies[1:],colors):
    axes[0].plot(ks,[100*float(row(p,k)['prediction_recall']) for k in ks],marker='o',label=labels[p],color=color)
    axes[1].plot(ks,[float(row(p,k)['mean_ready_cache_ttft_ms']) for k in ks],marker='o',label=labels[p],color=color)
for ax in axes:
    ax.set_xlabel('Prefetch budget K'); ax.set_xticks(ks); ax.grid(alpha=.2)
    ax.spines[['top','right']].set_visible(False)
axes[0].set_ylabel('Prediction recall (%)');axes[1].set_ylabel('Ready-cache TTFT (ms)')
axes[0].legend(fontsize=7,loc='lower right')
fig.tight_layout();fig.savefig(ROOT/'figures/qwen_results.pdf',bbox_inches='tight');plt.close(fig)
print('Generated all result tables and vector chart.')
