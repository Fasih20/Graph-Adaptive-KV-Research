# GraphKV supervisor-review manuscript

This is a new editable draft based on the earlier main.tex and supplied results.
It uses the official ICLR 2026 style, with a research-manuscript header rather
than a conference acceptance/submission claim.

## Open in Overleaf

Upload this ZIP as a new project. Select main.tex as the main document and
pdfLaTeX as the compiler. The vector figure and generated tables are included,
so Python is not required to compile.

Local compilation: pdflatex main.tex; bibtex main; pdflatex main.tex;
pdflatex main.tex.

To regenerate result tables and the vector chart, install matplotlib and run
python build_results.py.

## Review before sharing

This is an AI-assisted draft, not a human-written manuscript. Read it, check it
against your experiment records, and revise it in your own words before
presenting it as your writing. The author block retains the original source's
review placeholder; add the agreed author list.

The original source is preserved as original_main_2026_08_01.tex for reference.
It is not the compilation target and its older figures are not required by
this new draft.

## Data provenance

- data/archived_simulation_summary.json: supplied fjf.zip archive,
  foreaseReasults/summary_metrics.json. Includes six model configurations.
  Dataset pools and available policies differ and are labelled. The old
  adaptive policy is query-type-conditioned.
- data/qwen_real_means.csv: exact headline CSV from the completed
  hotpot_qwen15b_full_confirm run. All three K values and five policies
  are retained. This is an exact per-chunk cache-access microbenchmark
  with a controlled synthetic trace.
- data/api_summary.csv: transcription of the supplied Hotpot and 2Wiki
  Gemini-3.5-Flash-Lite tables. Both completion files report 240 events
  over 60 questions. Raw question-level API files and resolved provider
  model metadata were not supplied for this draft. Means retain the
  supplied precision; no confidence intervals were fabricated.

Method distinctions reflected in the manuscript:

- vLLM Top-M is 20; the supplied API wrapper defaults to 5.
- Real offline weights are 0.45 semantic / 0.55 structural. The API fits
  separately; check each run's fitted_policy.json before adding its weights.
- Real adaptation fits target recall; API adaptation fits support recall
  before context truncation. API online feedback uses labelled support.
- Fixed and adaptive two-hop aggregation differ, as documented in the code.
- Audit-model residency is not a direct GPU-residency measurement.
- Ready-cache TTFT excludes population; E2E includes it. Both and the
  no-prefetch comparator appear in the manuscript.

## Files

- main.tex: new manuscript.
- references.bib: checked primary-source references.
- tables/: generated LaTeX tables, including all archived K values.
- figures/qwen_results.pdf: vector figure.
- build_results.py: summary-to-table/plot conversion.
- original_main_2026_08_01.tex: preserved historical source.

Official style source: https://github.com/ICLR/Master-Template
Style archive: https://github.com/ICLR/Master-Template/raw/master/iclr2026.zip
