# September 2026 result integration

The submitted abstract in `main.tex` was preserved byte for byte. Its SHA-256 digest is:

`90666134dda1ae4dcc6017ec42e95355231bc2b876c57ec5a2bcba12ccf4e76a`

The revision adds:

- Llama-3.2-1B Hotpot real-cache results for K = 6, 10, and 16.
- Qwen2.5-1.5B and Llama-3.2-1B 2Wiki real-cache results at K = 10.
- The standardized semantic-only, structure, two-hop, offline, and online component ablation.
- The M/K CPU prediction-policy sensitivity study.
- The full 600-event asynchronous run at 750 ms lead.
- The 60-event lead-time pilot at 1000 and 1250 ms.
- Paired confidence intervals and the Hotpot-versus-2Wiki answer-quality mechanism analysis.

Exact aggregate source files for these additions are stored in `data_revision/`. The manuscript distinguishes synchronous real-cache measurements, asynchronous timing, CPU-only policy replay, and Gemini answer-quality evaluation; these quantities should not be merged into one latency claim.
