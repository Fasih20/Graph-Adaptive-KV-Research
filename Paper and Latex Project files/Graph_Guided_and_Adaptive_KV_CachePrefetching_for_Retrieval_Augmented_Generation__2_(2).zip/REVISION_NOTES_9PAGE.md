# Nine-page compliance revision

- The submitted abstract is unchanged.
- Main-paper content, including deferred main-result floats, occupies pages 1--8.
- References begin on page 9 and do not count toward the ICLR 2027 main-text limit.
- Appendix A begins on page 10.
- Detailed archived simulation, reproduction, diagnostic, cross-model, and asynchronous-ablation material remains in the appendix.
- The main paper retains the principal Qwen table and figure, cross-model/cross-dataset comparison, synchronous E2E accounting, M sensitivity, asynchronous lead-time crossover, answer-quality results, and paired confidence intervals.
- No font, margin, or spacing changes were used to obtain compliance.
